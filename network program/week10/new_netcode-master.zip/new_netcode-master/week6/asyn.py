import asyncio

async def main():
    print('watcharachai')

asyncio.run(main())
