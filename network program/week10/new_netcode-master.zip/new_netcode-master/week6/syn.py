import asyncio

def foo():
     return
     
foo()
print('watcharachai')
