import getpass
from pickle import TRUE
import telnetlib

HOST = "192.168.44.128"
user = "test6306022610067"
password = "6306022610067"
k = 0
try:
    tn = telnetlib.Telnet(HOST)
    tn.read_until(b"login: ")
    tn.write(user.encode('ascii') + b"\n")
    if password:
        tn.read_until(b"Password: ")
        tn.write(password.encode('ascii') + b"\n")
   
    while True:
        

           
            cmd = input("$>")
            if cmd == "exit": 
                tn.close()
                break
            tn.write(f"{cmd}\n".encode('UTF-8'))
            print(tn.read_very_eager().decode('ascii'))
        
except Exception as err:
    print(str(err))
